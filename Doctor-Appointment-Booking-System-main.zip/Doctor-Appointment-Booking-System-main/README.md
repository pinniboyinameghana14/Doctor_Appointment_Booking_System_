# Doctor-Appointment-Booking-System
Doctor Appointment Booking System is a Python-based application that allows patients to register, view doctors, and book appointments based on availability. It automates scheduling, prevents double bookings, and demonstrates core Python, database integration, and CRUD operations in a real-world healthcare use case.
