from django.apps import AppConfig


class DoctorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Doctor_App'
